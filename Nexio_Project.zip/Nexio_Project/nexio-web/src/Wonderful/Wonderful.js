import React from 'react';
import './Wonderful.css';
import Wonderfull from '../Images/7.png'; // Ensure the path is correct

const TestimonialComponent = () => {
  return (
    <div className="testimonial-container">
      <img 
        src={Wonderfull} 
        alt="Cabin Background" 
        className="background-imagesss" 
      />
      <div className="content-overlay">
        <h1 className="text-overlay">A truly wonderful<br/> 
        experience</h1> {/* Added text */}
        <p>Brilliant for anyone looking to get away from the hustle and 
        bustle of city life or detox from their tech for a few days. I 
        could have stayed another week!</p>
        <p>They really have thought about everything here down to the 
        finest details</p>
        <div className="trustpilots">
            <div className="stars6">
                <span>★</span>
            </div>
            <div className="stars7">
                <span>★</span>
            </div>
            <div className="stars8">
                <span>★</span>
            </div>
            <div className="stars9">
                <span>★</span>
            </div>
            <div className="stars10">
                <span>★</span>
            </div>
            <p> 01 Jan 2023</p>

          
        </div>

      </div>
    </div>
  );
};

export default TestimonialComponent;
