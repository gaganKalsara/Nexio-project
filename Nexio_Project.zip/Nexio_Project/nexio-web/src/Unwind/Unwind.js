import React from 'react';
import Unwind from '../Images/19.jpeg'; 
import Unwinds from '../Images/13.png'; // Correct path
import './Unwind.css';  // Import the CSS file here

const Text = () => {
  return (
    <div className="nature-retreats">
      <div className="Text-part">
          <h2>Get ready to unwind</h2>
          <p> A cabin getaway can be a wonderful way to relax 
            and reconnect with nature. Many cabin rentals are 
            located in beautiful, secluded areas, surrounded 
            by trees and other natural beauty.</p>
            <p>A cabin getaway can be a wonderful way to 
              escape the hustle and bustle of daily life and 
              reconnect with nature.
            </p>
            <button className="see-all-thing">Learn More &gt;</button>

      </div>

          {/* Circle grid behind the main image */}
      <div className="circle-grid">
        {Array.from({ length: 144 }).map((_, index) => (
          <div key={index} className="circle"></div>
        ))}
      </div>

      {/* Main image */}
      <img src={Unwind} alt="Nature Retreat" className="retreat-image" />

      {/* Additional small image positioned on top of the main image */}
      <img src={Unwinds} alt="Nature Retreats" className="retreat-images" />




      
    </div>
  );
};

export default Text;
