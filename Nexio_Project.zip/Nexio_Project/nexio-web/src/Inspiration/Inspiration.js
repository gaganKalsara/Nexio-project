import React from 'react';
import './Inspiration.css';
import cabinBackground1 from '../Images/11.png'; // Import the image
import cabinBackground2 from '../Images/12.jpeg';
import cabinBackground3 from '../Images/18.jpeg';

const getaways = [
  {
    id: 1,
    image: cabinBackground1, // Use the imported image
    category: 'FOR THOSE WHO LOVE',
    title: 'To Explore nature',
    description: 'Discover some of the most beautiful scenery from the wonders of Snowdonia to the famous beauty of the Scottish Highlands.'
  },
  {
    id: 2,
    image: cabinBackground2,
    category: 'FOR THOSE WHO WANT',
    title: 'To Relax, rest & re-set',
    description: 'Experience mind and body connection through breathing exercises and relaxation with our Yoga inspired get away for you and the family.'
  },
  {
    id: 3,
    image: cabinBackground3,
    category: 'FOR THOSE WHO HAVE',
    title: 'Four-legged friends',
    description: 'When going on holiday nobody wants to put their dog in a kennel. So, lets keep the family together with our pet friendly cabins.'
  }
];


const VacationInspiration = () => {
  return (
    <div className="vacation-container">
      <div className="vacation-header">
        <h2>Inspiration for your next getaway</h2>
        <p>We've curated some amazing experiences to help you find your next getaway.</p>
        <a href="#" className="view-all">View all experiences</a>
      </div>
      
      <div className="getaway-grid">
        {getaways.map((getaway) => (
          <div key={getaway.id} className="getaway-card">
            <img src={getaway.image} alt={getaway.title} className="getaway-image" />
            <div className="getaway-content">
              <span className="category">{getaway.category}</span>
              <h3>{getaway.title}</h3>
              <p>{getaway.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VacationInspiration;