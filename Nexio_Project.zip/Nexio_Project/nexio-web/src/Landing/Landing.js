import React from 'react';
import './Landing.css';

const LandingPage = () => {
  return (
    <div className="landing-page">
      <div className="contents">
        <h1>Escape from endless Zoom calls</h1>
        <h5>Discover the wonders of spending time offline and away from the office with our 3 day weekend getaway cabin retreats.</h5>
        <button className="cta-button">Find the perfect getaway</button>
      </div>
      <div className="image-overlay"></div>
    </div>
  );
};

export default LandingPage;
