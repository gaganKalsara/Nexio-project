import React from 'react';
import { MapPin, Calendar, Users, Space } from 'lucide-react';
import './Home.css';

// Import images from the src folder
import image1 from '../Images/1.jpeg';
import image2 from '../Images/2.jpeg';
import image3 from '../Images/3.jpeg';
import image4 from '../Images/4.jpeg';
import image5 from '../Images/5.jpeg';
import image6 from '../Images/6.jpeg';

const CabinRental = () => {
  return (
    <div className="cabin-rental">
      {/* Use imported image for the large background image */}
      <img src={image1} alt="Forest cabin" className="background-image" />
      <div className="overlay">
        <div className="content">
          {/* Move h1 to the left side */}
          <h1>
                Leave the office behind <br />
                and <span className="highlight">unwind</span>
            </h1>

          <h6>
            Welcome to our cozy cabin nestled in the heart of the mountains!<br />
            Our cabin is the perfect getaway for those seeking peace and<br />
            relaxation in a natural setting.
          </h6>
          <div className="rating">
            <div className="user-avatars">
              {/* Use imported images for avatar images */}
              {[image2, image3, image4, image5, image6].map((image, index) => (
                <img key={index} src={image} alt={`User ${index + 1}`} className="avatar" />
              ))}
            </div>
                <div className="trustpilot">
                    <span className="trustpilot-text">★  Trustpilot</span>
                    <div className="stars">
                        <span>★</span>
                    </div>
                    <div className="stars1">
                        <span>★</span>
                    </div>
                    <div className="stars2">
                        <span>★</span>
                    </div>
                    <div className="stars3">
                        <span>★</span>
                    </div>
                    <div className="stars4">
                        <span>★</span>
                    </div>

                    <span className="score">4.5 / 5</span>
                </div>
                
            </div>
        </div>
        <div className="search-bar">
          <div className="search-options">
            <button className="search-option">
              <MapPin className="icon" />
              I want to go
            </button>
            <button className="search-option">
              <Calendar className="icon" />
              Check in
            </button>
            <button className="search-option">
              <Calendar className="icon" />
              Check out
            </button>
            <button className="search-option">
              <Users className="icon" />
              Travellers
            </button>
          </div>
          <button className="find-cabins">
            Find available cabins
          </button>
        </div>
      </div>
    </div>
  );
};

export default CabinRental;
