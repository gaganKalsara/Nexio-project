import React from 'react';
import './Banner.css';
import myImage from '../Images/15.jpeg'; // Adjust the path as necessary

const WellnessBanner = () => {
  return (
    <div className="banner-container">
      {/* Banner Image Container */}
     
          <div className="banner-image-container">
            <img
              src={myImage}
              alt="Person relaxing and reading"
              className="banner-image"
            />
        
        <div className="banner-overlay"> </div>
     </div>
      {/* Banner Content */}
      <div className="banner-content">
        <h1 className="banner-title">
          Nourish the mind, body,<br />and spirit.
        </h1>

        <p className="banner-text">
          Many people find that the combination of being in a peaceful natural 
          setting and engaging in activities that nourish the mind, body, and spirit 
          leave them feeling rejuvenated and refreshed.
        </p>

        <button className="banner-button">
          Find available cabins
        </button>
      </div>
    </div>
  );
};

export default WellnessBanner;
