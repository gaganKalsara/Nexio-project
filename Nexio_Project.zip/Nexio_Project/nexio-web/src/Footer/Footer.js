import React from 'react';
import './Footer.css';

const footerLinks = {
    'About us': ['Our story', 'Why us', 'How it works', 'FAQ'],
    'Our cabins': {
        'North of London': ['Golden Hideaway', 'Oak Treehouse', 'Acacia Retreat', 'Blue Lagoon'],
        'South of London': ['Lavender Retreat', 'Butterfly Treehouse', 'Mahogany Hideaway']
    },
    'Get inspired': {
        'Explore nature': ['Hiking trails', 'Swimming', 'Fishing', 'Boating', ],
        'Rest, relax and re-set': ['Spa treatments', 'Hot tubs', 'Nature Trails']
    },
    "": {  // Empty key to represent the section without a title
        'Great food and drink': ['Pubs', 'Restaurants', 'Food markets', 'Picnics'],
        'For you and yours': ['Solo or a couple', 'Pet friendly', 'Accessible cabins']
    },
    'Support': ['Help', 'Contact us', 'Privacy Policy', 'Terms of Service', 'Complaints Policy']
};

const Footer = () => {
    return (
        <footer className="footer">
            <div className="footer-container">
                {/* Main Footer Links */}
                <div className="footer-links">
                    {Object.entries(footerLinks).map(([category, items]) => (
                        <div key={category} className="footer-column">
                            {/* Render category only if it's not an empty string */}
                            {category.trim() !== '' && <h3 className="footer-category">{category}</h3>}
                            {typeof items === 'object' && !Array.isArray(items) ? (
                                <>
                                    {category === "" && <><br /><br /></>} {/* Render two line breaks if category is empty */}
                                    <div className="footer-subcategories-flex"> {/* Flex container for the subcategories */}
                                        {Object.entries(items).map(([subCategory, subItems]) => (
                                            <div key={subCategory} className="footer-subcategory">
                                                {subCategory.trim() !== '' && <h4>{subCategory}</h4>} {/* Only render if subCategory is not empty */}
                                                <ul>
                                                    {subItems.map((item) => (
                                                        <li key={item}>
                                                            <a href="#">{item}</a>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        ))}
                                    </div>
                                </>
                            ) : (
                                <ul>
                                    {items.map((item) => (
                                        <li key={item}>
                                            <a href="#">{item}</a>
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    ))}
                </div>

                {/* Newsletter Section */}
                <div className="newsletter-section">
                    <h3>Sign up to our Newsletter</h3>
                   
                    <div className="newsletter-form">
                    <p>
                        For a weekly curated collection of 3 things you can watch, read, or listen to switch off from the busy everyday.
                    </p>
                        <input
                            type="email"
                            placeholder="james@thegoingpeach.com"
                            className="newsletter-input"
                        />
                        <button className="newsletter-button">
                            Join the mailing list
                        </button>
                    </div>
                </div>

                {/* Footer Bottom */}
                <div className="footer-bottom">
                    <div className="footer-logo">
                        UNWIND<span>CABINS</span>
                    </div>
                    <div className="footer-copyright">© 2023 UnwindCabins</div>
                    <div className="social-icons">
                        <a href="#" className="social-icon">LinkedIn</a>
                        <a href="#" className="social-icon">Twitter</a>
                        <a href="#" className="social-icon">Facebook</a>
                        <a href="#" className="social-icon">Instagram</a>
                        <a href="#" className="social-icon">YouTube</a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
