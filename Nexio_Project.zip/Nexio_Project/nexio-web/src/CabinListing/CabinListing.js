import React from 'react';
import { Heart } from 'lucide-react';
import './CabinListing.css';


const cabinsData = [
    {
      id: 1,
      image: require('../Images/8.jpeg'),
      location: "HAMPSHIRE - ENGLAND",
      title: "Rustic country retreat",
      price: "210",
      rating: 4,
      reviews: 82,
      description: "Step outside and take in the stunning views. Our cabin sits on a quiet and secluded property, providing the perfect setting for a peaceful retreat."
    },
    {
      id: 2,
      image: require('../Images/9.jpeg'),
      location: "NORFOLK - ENGLAND",
      title: "Cozy getaway cabin",
      price: "312",
      rating: 4,
      reviews: 82,
      description: "Step outside and take in the stunning views. Our cabin sits on a quiet and secluded property, providing the perfect setting for a peaceful retreat."
    },
    {
      id: 3,
      image: require('../Images/10.jpeg'),
      location: "HAMPSHIRE - ENGLAND",
      title: "Rustic country retreat",
      price: "210",
      rating: 4,
      reviews: 82,
      description: "Step outside and take in the stunning views. Our cabin sits on a quiet and secluded property, providing the perfect setting for a peaceful retreat."
    }
  ];
  

const CabinListings = () => {
  return (
    <div className="listings-container">
      <div className="listings-header">
        <div className="header-content">
          <h2>Discover our idyllic countryside cabins</h2>
          <p>Fully equipped kitchen and bathroom with plenty of walking and cycling routes to explore.</p>
        </div>
        <button className="view-all-thing">View all cabins</button>
      </div>

      <div className="cabins-grid">
        {cabinsData.map((cabin) => (
          <div key={cabin.id} className="cabin-card">
            <div className="image-container">
              <img
                src={cabin.image}
                alt={cabin.title}
                className="cabin-image"
              />
              <button className="heart-button">
                <Heart className="heart-icon" />
              </button>
            </div>

            <div className="cabin-content">
            <span className="location">{cabin.location}</span>

              <div className="location-price">
               
                <h3 className="title">{cabin.title}</h3>
                <span className="price">£{cabin.price}<span className="per-person">pp</span></span>
              </div>
              
              <p className="description">{cabin.description}</p>
              
              <div className="rating-container">
                {[...Array(5)].map((_, i) => (
                  <svg
                    key={i}
                    className={`star ${i < cabin.rating ? 'filled' : ''}`}
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
                <span className="reviews">{cabin.reviews} reviews</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CabinListings;
