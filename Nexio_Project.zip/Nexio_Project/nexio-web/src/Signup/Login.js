import React, { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/signup", { email, password }, { withCredentials: true });
      if (res.data.data === "Login successful") {
        navigate("/");
      }
    } catch (err) {
      setError("Login failed. Please check your credentials.");
    }
  };

  return (
    <div style={styles.background}>
      <div style={styles.loginContainer}>
        <h2 style={styles.title}>LOGGIN PAGE</h2>
        {error && <p style={styles.error}>{error}</p>}
        <form onSubmit={handleSubmit} style={styles.form}>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            placeholder="Email Address"
            style={styles.input}
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            placeholder="Password"
            style={styles.input}
          />
          <button type="submit" style={styles.button}>LOGIN</button>
        </form>
        <p style={styles.registerText}>
          Don't have an account? <Link to="/register" style={styles.registerLink}>Register here</Link>
        </p>
      </div>
    </div>
  );
};

const styles = {
  background: {
    backgroundColor: '#4a2828',
    minHeight: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loginContainer: {
    backgroundColor: 'white',
    padding: '50px',
    borderRadius: '15px',
    width: '500px',
    boxShadow: '0 6px 10px rgba(0, 0, 0, 0.1)',
  },
  title: {
    textAlign: 'center',
    marginBottom: '30px',
    color: '#333',
    fontWeight: 'bold',
    fontSize: '32px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
  },
  input: {
    marginBottom: '25px',
    padding: '15px',
    border: '1px solid #ddd',
    borderRadius: '6px',
    fontSize: '18px',
  },
  button: {
    backgroundColor: '#ff3b3b',
    color: 'white',
    padding: '15px',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: '20px',
    marginBottom: '20px',
  },
  error: {
    color: 'red',
    textAlign: 'center',
    marginBottom: '15px',
    fontSize: '16px',
  },
  registerText: {
    textAlign: 'center',
    fontSize: '16px',
    color: '#333',
  },
  registerLink: {
    color: '#ff3b3b',
    textDecoration: 'none',
    fontWeight: 'bold',
  },
};

export default Login;