import React, { useState } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './Navbar/Navbar';
import Footer from './Footer/Footer';
import Home from './Home/Home';  // Home component with other sections
import CabinListings from './CabinListing/CabinListing';
import Inspiration from './Inspiration/Inspiration';
import Wonderful from './Wonderful/Wonderful';
import Unwind from './Unwind/Unwind';
import Banner from './Banner/Banner';
import FAQ from './Faq/Faq';
import Landing from './Landing/Landing';
import Register from './Signup/Register';
import Login from './Signup/Login';

function App() {
  return (
    <div className="App">
      <Router>
        <div className="App">
          {/* Pass isLoggedIn to Navbar */}
          <Navbar />
          <Routes>
            {/* Define homepage route */}
            <Route path="/" element={
              <>
                <Home />
                <CabinListings />
                <Inspiration />
                <Wonderful />
                <Unwind />
                <Banner />
                <FAQ />
                <Landing />
                <Footer />
              </>
            } />

            {/* Signup page route */}
            <Route path="/signup" element={<Login />} />
            <Route path="/register" element={<Register />} />
          </Routes>
        </div>
      </Router>
    </div>
  );
}

export default App;
