import React, { useState } from 'react';
import { ChevronRight } from 'lucide-react';
import './Faq.css';

const FAQ = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const faqData = [
    {
      title: '1. About Unwind Cabins',
      questions: [
        'How long have you been in business?',
        'Why did you start this journey?'
      ]
    },
    {
      title: '2. Tell me more about the cabin',
      questions: [
        'What do I need to bring?',
        'How do I get to the cabin?'
      ]
    },
    {
      title: '3. Pets, family & friends',
      questions: [
        'Please tell me I can bring my dog',
        'How many people do your cabins sleep?'
      ]
    }
  ];

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <div className="faq-container">
      <h2 className="faq-title">Frequently asked questions</h2>
      {faqData.map((item, index) => (
        <div key={index} className="faq-item">
          <div className="faq-question-list">
            <h3>{item.title}</h3>
            <ul>
              {item.questions.map((question, qIndex) => (
                <li key={qIndex}>{question}</li>
              ))}
            </ul>
          </div>
          <button 
            className={`faq-button ${activeIndex === index ? 'active' : ''}`}
            onClick={() => toggleAccordion(index)}
          >
            {item.title}
            <ChevronRight className={`chevron ${activeIndex === index ? 'rotate' : ''}`} />
          </button>
        </div>
      ))}
      <div className="faq-footer">
        <h3>Still have a question?</h3>
        <p>If you still have questions contact a member of the team on <span className="live-chat">live chat</span> and we'd be more than happy to help.</p>
      </div>
    </div>
  );
};

export default FAQ;