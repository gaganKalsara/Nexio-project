import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Navbar.css'; // Assuming you have styling
import { LogOut } from 'lucide-react';

function Navbar() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Check login status when component mounts
    const checkLoginStatus = async () => {
      try {
        const res = await axios.get("http://localhost:5000/home", { withCredentials: true });
        if (res.status === 200) {
          setIsLoggedIn(true);  // User is logged in
        }
      } catch (err) {
        setIsLoggedIn(false);  // User is not logged in
      }
    };
    checkLoginStatus();
  }, []);  // Runs only once when component mounts

  const handleLogout = async () => {
    try {
      await axios.post("http://localhost:5000/logout", {}, { withCredentials: true });
      setIsLoggedIn(false);  // Set logged-in state to false after logout
      navigate('/');  // Redirect to home after logging out
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  return (
    <nav>
      {/* UNWIND and CABINS styled differently but appearing as one word */}
      <div className="brand">
        <span className="brand1">UNWIND</span><span className="brand2">CABINS</span>
      </div>
      <ul>
        <li><Link to="/">Our cabins</Link></li>
        <li><Link to="/contact">Get inspired</Link></li>
        <li><Link to="/gift-a-stay">Gift a stay</Link></li>
        <li><Link to="/about">About us</Link></li>
        <li>
          {isLoggedIn ? (
            <button className="logout-button" onClick={handleLogout}>
              <LogOut size={20} />
            </button>
          ) : (
            <Link to="/signup" className="signup-button">
              Sign Up
            </Link>
          )}
        </li>
      </ul>
    </nav>
  );
}

export default Navbar;
