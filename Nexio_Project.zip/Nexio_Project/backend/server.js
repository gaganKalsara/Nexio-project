require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const userRoutes = require('./routes/user_routes');
const UserModel = require('./models/User'); // Ensure this path is correct
const app = express();

// Middleware to log request path and method
app.use((req, res, next) => {
    console.log(req.path, req.method);
    next();
});

// Middleware setup
app.use(cors({
    origin: ["http://localhost:3000"],
    methods: ["GET", "POST", "PUT", "DELETE", "PATCH"],
    credentials: true
}));
app.use(express.json());
app.use(cookieParser()); // Enable cookie parsing for handling JWT tokens

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI, {})
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch((error) => {
        console.error('Error connecting to MongoDB:', error);
    });

// Authentication Middleware
const verifyUser = (req, res, next) => {
    const token = req.cookies.token;
    if (!token) {
        return res.status(401).json({ error: "No token provided" });
    }
    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(401).json({ error: "Invalid token" });
        }
        req.user = decoded;
        next();
    });
};

// Authentication Routes
app.post("/register", (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    if (password.length < 6) {
        return res.status(400).json({ error: 'Password must be at least 6 characters long' });
    }

    UserModel.findOne({ email: email })
        .then((existingUser) => {
            if (existingUser) {
                return res.status(400).json({ error: "Email already in use" });
            }

            bcrypt.hash(password, 10)
                .then((hash) => {
                    UserModel.create({ name, email, password: hash })
                        .then((user) => res.status(201).json(user))
                        .catch((err) => res.status(500).json({ error: err.message }));
                })
                .catch((err) => res.status(500).json({ error: err.message }));
        });
});

app.post("/signup", (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    UserModel.findOne({ email: email })
        .then((user) => {
            if (!user) {
                return res.status(404).json({ error: "User not found" });
            }

            bcrypt.compare(password, user.password, (err, response) => {
                if (!response) {
                    return res.status(400).json({ error: "Incorrect password" });
                }

                const token = jwt.sign({ _id: user._id, email: user.email }, process.env.JWT_SECRET, { expiresIn: "1d" });
                res.cookie("token", token, { httpOnly: true });
                return res.json({ data: "Login successful" });
            
            });
        })
        .catch((err) => res.status(500).json({ error: err.message }));
});

app.post("/logout", (req, res) => {
    res.clearCookie("token");
    return res.json({ message: "Logged out successfully" });
});

// Protected Routes
app.use('/api/user', userRoutes);

app.get('/home', verifyUser, (req, res) => {
    return res.json({ data: "User access granted", user: req.user });
});

// Server listening on the port
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`);
});
